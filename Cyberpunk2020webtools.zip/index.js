const launcherLoadBtn=document.getElementById('launcher-load-btn');
const launcherFileInput=document.getElementById('launcher-file-input');
const launcherCreateBtn=document.getElementById('launcher-create-btn');
const launcherModal=document.getElementById('launcher-modal');
const launcherCancelBtn=document.getElementById('launcher-cancel-btn');
const launcherForm=document.getElementById('launcher-form');
const launcherStatus=document.getElementById('launcher-status');
let launcherHoverAudio=null;
let launcherHoveredButton=null;

function launcherZipReady(){
  return typeof JSZip!=='undefined';
}

function launcherLooksLikeCharacterText(text){
  const lower=String(text||'').toLowerCase();
  return lower.includes('name:')&&lower.includes('stats:')&&lower.includes('career:');
}

function launcherMimeForImage(filename=''){
  const lower=filename.toLowerCase();
  if(lower.endsWith('.jpg')||lower.endsWith('.jpeg'))return'image/jpeg';
  if(lower.endsWith('.gif'))return'image/gif';
  if(lower.endsWith('.webp'))return'image/webp';
  if(lower.endsWith('.bmp'))return'image/bmp';
  return'image/png';
}

async function launcherExtractZipBundle(file){
  if(!launcherZipReady())throw new Error('ZIP SUPPORT FAILED TO LOAD.');
  const zip=await JSZip.loadAsync(await file.arrayBuffer());
  const entries=Object.values(zip.files).filter(entry=>!entry.dir);
  const textEntries=[];
  let banner=null;
  for(const entry of entries){
    const name=entry.name.split('/').pop();
    const lower=name.toLowerCase();
    if(lower.endsWith('.txt')){
      textEntries.push({name,text:await entry.async('string')});
      continue;
    }
    if(!banner&&/\.(png|jpe?g|gif|webp|bmp)$/i.test(lower)){
      banner={name,dataUrl:`data:${launcherMimeForImage(name)};base64,${await entry.async('base64')}`};
    }
  }
  const characterEntry=textEntries.find(entry=>/^(character|dossier|sheet)\.txt$/i.test(entry.name))||textEntries.find(entry=>launcherLooksLikeCharacterText(entry.text))||null;
  return {
    characterText:characterEntry?.text||'',
    itemTexts:textEntries.filter(entry=>entry!==characterEntry).map(entry=>entry.text),
    banner
  };
}

function setLauncherStatus(message){
  launcherStatus.textContent=message;
  launcherStatus.classList.add('show');
}

function clearLauncherStatus(){
  launcherStatus.textContent='';
  launcherStatus.classList.remove('show');
}

function openLauncherModal(){
  clearLauncherStatus();
  launcherModal.classList.add('show');
  launcherModal.setAttribute('aria-hidden','false');
  document.getElementById('launcher-name').focus();
}

function closeLauncherModal(){
  launcherModal.classList.remove('show');
  launcherModal.setAttribute('aria-hidden','true');
}
function playLauncherHoverSound(){
  if(!launcherHoverAudio){
    launcherHoverAudio=new Audio('audio/menu-hover.mp3');
    launcherHoverAudio.preload='auto';
  }
  launcherHoverAudio.currentTime=0;
  launcherHoverAudio.play().catch(()=>{});
}
document.addEventListener('mouseover',(event)=>{
  const button=event.target.closest('button');
  if(!button)return;
  if(button===launcherHoveredButton)return;
  if(button.contains(event.relatedTarget))return;
  launcherHoveredButton=button;
  playLauncherHoverSound();
});
document.addEventListener('mouseout',(event)=>{
  const button=event.target.closest('button');
  if(!button)return;
  if(button===launcherHoveredButton && !button.contains(event.relatedTarget)){
    launcherHoveredButton=null;
  }
});

function buildLauncherCharacterData(name,street,career){
  const aliases=street?[street]:[];
  return {
    name:[name,...aliases],
    stats:{REF:0,INT:0,COOL:0,ATTR:0,TECH:0,LUCK:0,EMPT:0},
    career:[career],
    careerSkill:{point:0},
    reputation:{rep:0},
    wallet:{eddies:0},
    physicalBody:{bodylevel:0,weight:0,stunpoint:0},
    body:{},
    stunpoint:{},
    armor:{Head:0,Torso:0,'R.Arm':0,'L.Arm':0,'R.Leg':0,'L.Leg':0},
    damage:{Head:0,Torso:0,'R.Arm':0,'L.Arm':0,'R.Leg':0,'L.Leg':0},
    inventory:{}
  };
}

launcherLoadBtn.addEventListener('click',()=>{
  clearLauncherStatus();
  launcherFileInput.value='';
  launcherFileInput.click();
});

launcherFileInput.addEventListener('change',(event)=>{
  const file=event.target.files?.[0];
  if(!file)return;
  const lowerName=file.name.toLowerCase();
  if(lowerName.endsWith('.zip')){
    launcherExtractZipBundle(file).then((bundle)=>{
      if(!bundle.characterText){
        setLauncherStatus('CHARACTER.TXT NOT FOUND IN ZIP.');
        return;
      }
      window.startChippinInTransition({bundleData:bundle});
    }).catch((error)=>{
      setLauncherStatus('FAILED TO READ ZIP DOSSIER.');
    });
    return;
  }
  if(!lowerName.endsWith('.txt')){
    setLauncherStatus('ONLY .TXT OR .ZIP DOSSIERS ARE SUPPORTED.');
    return;
  }
  const reader=new FileReader();
  reader.onload=(loadEvent)=>{
    window.startChippinInTransition({rawText:String(loadEvent.target?.result||'')});
  };
  reader.onerror=()=>setLauncherStatus('FAILED TO READ DOSSIER FILE.');
  reader.readAsText(file);
});

launcherCreateBtn.addEventListener('click',openLauncherModal);
launcherCancelBtn.addEventListener('click',closeLauncherModal);

launcherModal.addEventListener('click',(event)=>{
  if(event.target===launcherModal)closeLauncherModal();
});

launcherForm.addEventListener('submit',(event)=>{
  event.preventDefault();
  const name=document.getElementById('launcher-name').value.trim();
  const street=document.getElementById('launcher-street').value.trim();
  const career=document.getElementById('launcher-career').value.trim();
  if(!name||!career){
    setLauncherStatus('NAME AND CAREER ARE REQUIRED.');
    return;
  }
  closeLauncherModal();
  window.startChippinInTransition({
    characterData:buildLauncherCharacterData(name,street,career)
  });
});
